import asyncio
import os
import random
import sqlite3
from datetime import date, datetime, timezone

from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command, CommandStart
from aiogram.types import Message
from aiogram.utils.keyboard import ReplyKeyboardBuilder

TOKEN = os.getenv("BOT_TOKEN")
DB_PATH = os.getenv("DB_PATH", "derevabot.sqlite3")

if not TOKEN:
    raise RuntimeError("BOT_TOKEN is missing. Set it as an environment variable on the server.")

bot = Bot(TOKEN)
dp = Dispatcher()


def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS players (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                first_name TEXT NOT NULL,
                cash INTEGER NOT NULL DEFAULT 500,
                bank INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL,
                last_daily TEXT
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS work_log (
                user_id INTEGER PRIMARY KEY,
                last_work_ts TEXT
            )
        """)


def ensure_player(message: Message):
    user = message.from_user
    if not user:
        return
    with db() as conn:
        conn.execute("""
            INSERT INTO players (user_id, username, first_name, created_at)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
                username=excluded.username,
                first_name=excluded.first_name
        """, (
            user.id, user.username, user.first_name or "Игрок",
            datetime.now(timezone.utc).isoformat()
        ))


def get_player(user_id: int):
    with db() as conn:
        return conn.execute("SELECT * FROM players WHERE user_id=?", (user_id,)).fetchone()


def main_keyboard():
    kb = ReplyKeyboardBuilder()
    for label in ("👤 Профиль", "💼 Работа", "🎁 Ежедневный бонус", "🏆 Топ игроков", "❔ Помощь"):
        kb.button(text=label)
    kb.adjust(2, 2, 1)
    return kb.as_markup(resize_keyboard=True)


@dp.message(CommandStart())
async def start(message: Message):
    ensure_player(message)
    await message.answer(
        "🌳 Добро пожаловать в <b>Древень</b> — текстовую RP-игру в Telegram!\n\n"
        "Твой персонаж создан. На старте у тебя 500 монет.\n"
        "Здесь нет очков опыта: развитие строится на игровой валюте и действиях.\n\n"
        "Используй кнопки меню или команду /help.",
        reply_markup=main_keyboard(),
        parse_mode="HTML"
    )


@dp.message(Command("help"))
@dp.message(F.text == "❔ Помощь")
async def help_cmd(message: Message):
    await message.answer(
        "<b>🌳 Древень — команды</b>\n\n"
        "/start — создать персонажа\n"
        "/profile — профиль и баланс\n"
        "/work — выполнить работу (перерыв 60 минут)\n"
        "/daily — ежедневная награда\n"
        "/top — рейтинг по наличным и банку\n"
        "/help — список команд\n\n"
        "Игровая валюта пока называется монетами. Очков опыта нет.",
        parse_mode="HTML"
    )


@dp.message(Command("profile"))
@dp.message(F.text == "👤 Профиль")
async def profile(message: Message):
    ensure_player(message)
    p = get_player(message.from_user.id)
    username = f"@{p['username']}" if p["username"] else p["first_name"]
    await message.answer(
        f"👤 <b>Профиль Древень</b>\n"
        f"Игрок: {username}\n"
        f"ID: <code>{p['user_id']}</code>\n"
        f"💰 Наличные: <b>{p['cash']:,}</b>\n"
        f"🏦 Банк: <b>{p['bank']:,}</b>\n"
        f"📅 В игре с: {p['created_at'][:10]}\n\n"
        "Очки опыта не используются.",
        parse_mode="HTML"
    )


@dp.message(Command("daily"))
@dp.message(F.text == "🎁 Ежедневный бонус")
async def daily(message: Message):
    ensure_player(message)
    today = date.today().isoformat()
    p = get_player(message.from_user.id)
    if p["last_daily"] == today:
        await message.answer("🎁 Ты уже забрал ежедневный бонус сегодня. Возвращайся завтра!")
        return
    reward = random.randint(250, 500)
    with db() as conn:
        conn.execute(
            "UPDATE players SET cash=cash+?, last_daily=? WHERE user_id=?",
            (reward, today, message.from_user.id)
        )
    await message.answer(f"🎁 Ежедневный бонус получен: +{reward:,} монет!")


@dp.message(Command("work"))
@dp.message(F.text == "💼 Работа")
async def work(message: Message):
    ensure_player(message)
    uid = message.from_user.id
    now = datetime.now(timezone.utc)
    with db() as conn:
        row = conn.execute("SELECT last_work_ts FROM work_log WHERE user_id=?", (uid,)).fetchone()
        if row and row["last_work_ts"]:
            last = datetime.fromisoformat(row["last_work_ts"])
            seconds = (now - last).total_seconds()
            if seconds < 3600:
                minutes = max(1, int((3600 - seconds + 59) // 60))
                await message.answer(f"⏳ Ты уже работал. Следующая работа будет доступна через {minutes} мин.")
                return
        reward = random.randint(100, 350)
        conn.execute("UPDATE players SET cash=cash+? WHERE user_id=?", (reward, uid))
        conn.execute("""
            INSERT INTO work_log(user_id, last_work_ts) VALUES(?, ?)
            ON CONFLICT(user_id) DO UPDATE SET last_work_ts=excluded.last_work_ts
        """, (uid, now.isoformat()))
    jobs = [
        "Ты помог жителям города и получил оплату.",
        "Ты доставил посылку по городу и заработал.",
        "Ты отработал смену в местной мастерской.",
        "Ты выполнил поручение владельца магазина."
    ]
    await message.answer(f"💼 {random.choice(jobs)}\n💰 Заработано: +{reward:,} монет.")


@dp.message(Command("top"))
@dp.message(F.text == "🏆 Топ игроков")
async def top(message: Message):
    ensure_player(message)
    with db() as conn:
        rows = conn.execute("""
            SELECT first_name, username, cash, bank, (cash+bank) AS total
            FROM players ORDER BY total DESC LIMIT 10
        """).fetchall()
    lines = ["🏆 <b>Топ-10 игроков Древень</b>\n"]
    for i, p in enumerate(rows, 1):
        name = "@" + p["username"] if p["username"] else p["first_name"]
        lines.append(f"{i}. {name} — <b>{p['total']:,}</b> монет")
    await message.answer("\n".join(lines), parse_mode="HTML")


@dp.message()
async def unknown(message: Message):
    await message.answer("Не понял команду. Напиши /help, чтобы посмотреть доступные действия.")


async def main():
    init_db()
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
